import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class blackPawn here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class blackPawn extends Black
{
    /**
     * Act - do whatever the blackPawn wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() {
        MouseInfo info = Greenfoot.getMouseInfo();
        if (Greenfoot.mouseDragged(this)) {
            MouseInfo mouse = Greenfoot.getMouseInfo();
            setLocation(round(mouse.getX()), round(mouse.getY()));
        }
        if (!(String.valueOf(getNeighbours(10, true, Actor.class)).equals("[]"))){
            // System.out.println(getNeighbours(50, true, Actor.class));
        }
    }
    public int round(int x) {
        if (x % 100 < 50) {
            return (x - (x % 100))+50;
        } else if (x%100 > 50) {
            return (x + (100 - (x%100)))-50; 
        } else if (x%100 == 50){
            return (x);
        }
        return x;
    }   
}
