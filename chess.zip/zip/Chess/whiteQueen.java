import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class whiteQueen here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class whiteQueen extends White
{
    /**
     * Act - do whatever the whiteQueen wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() {
        World mw = getWorld();
        MouseInfo info = Greenfoot.getMouseInfo();
        if (Greenfoot.mouseDragged(this)) {
            MouseInfo mouse = Greenfoot.getMouseInfo();
            String i = String.valueOf(mw.getObjectsAt(round(mouse.getX()), round(mouse.getY()), Actor.class));
            char c = i.charAt(1);
            if (c != 'w'){
                setLocation(round(mouse.getX()), round(mouse.getY())); 
            }  
        }
    }
    public int round(int x) {
        if (x % 100 < 50) {
            return (x - (x % 100))+50;
        } else if (x%100 > 50) {
            return (x + (100 - (x%100)))-50; 
        } else if (x%100 == 50){
            return (x);
        }
        return x;
    }  
}
