import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Piece extends Actor
{
    public void act() {
        MouseInfo info = Greenfoot.getMouseInfo();
        if (Greenfoot.mouseDragged(this)) {
            MouseInfo mouse = Greenfoot.getMouseInfo();
            setLocation(mouse.getX(),mouse.getY());
        }
        if (!(String.valueOf(getNeighbours(10, true, Actor.class)).equals("[]"))){
            System.out.println(getNeighbours(50, true, Actor.class));
        }
    }    
}
