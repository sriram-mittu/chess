import greenfoot.*;

public class ChessBoard extends greenfoot.World {
    public ChessBoard() {    
        super(800, 800, 1);
        setBackground("cb.png");
        prepare();
    }
    
    public void act() {
        
    }
    
    private void prepare() {
        blackRook blackRook = new blackRook();
        addObject(blackRook,50,50);
        blackRook blackRook2 = new blackRook();
        addObject(blackRook2,750,50);
        blackBishop blackBishop = new blackBishop();
        addObject(blackBishop,150,50);
        blackBishop blackBishop2 = new blackBishop();
        addObject(blackBishop2,650,50);
        blackNight blackNight = new blackNight();
        addObject(blackNight,550,50);
        blackNight blackNight2 = new blackNight();
        addObject(blackNight2,250,50);
        blackQueen blackQueen = new blackQueen();
        addObject(blackQueen,350,50);
        blackKing blackKing = new blackKing();
        addObject(blackKing,450,50);
        blackPawn blackPawn = new blackPawn();
        addObject(blackPawn,750,150);
        blackPawn blackPawn2 = new blackPawn();
        addObject(blackPawn2,650,150);
        blackPawn blackPawn3 = new blackPawn();
        addObject(blackPawn3,550,150);
        blackPawn blackPawn4 = new blackPawn();
        addObject(blackPawn4,450,150);
        blackPawn blackPawn5 = new blackPawn();
        addObject(blackPawn5,350,150);
        blackPawn blackPawn6 = new blackPawn();
        addObject(blackPawn6,250,150);
        blackPawn blackPawn7 = new blackPawn();
        addObject(blackPawn7,150,150);
        blackPawn blackPawn8 = new blackPawn();
        addObject(blackPawn8,50,150);
        whiteRook whiteRook = new whiteRook();
        addObject(whiteRook,50,750);
        whiteRook whiteRook2 = new whiteRook();
        addObject(whiteRook2,750,750);
        whiteBishop whiteBishop = new whiteBishop();
        addObject(whiteBishop,150,750);
        whiteBishop whiteBishop2 = new whiteBishop();
        addObject(whiteBishop2,650,750);
        whiteNight whiteNight = new whiteNight();
        addObject(whiteNight,550,750);
        whiteNight whiteNight2 = new whiteNight();
        addObject(whiteNight2,250,750);
        whiteQueen whiteQueen = new whiteQueen();
        addObject(whiteQueen,350,750);
        whiteKing whiteKing = new whiteKing();
        addObject(whiteKing,450,750);
        whitePawn whitePawn = new whitePawn();
        addObject(whitePawn,750,650);
        whitePawn whitePawn2 = new whitePawn();
        addObject(whitePawn2,650,650);
        whitePawn whitePawn3 = new whitePawn();
        addObject(whitePawn3,550,650);
        whitePawn whitePawn4 = new whitePawn();
        addObject(whitePawn4,450,650);
        whitePawn whitePawn5 = new whitePawn();
        addObject(whitePawn5,350,650);
        whitePawn whitePawn6 = new whitePawn();
        addObject(whitePawn6,250,650);
        whitePawn whitePawn7 = new whitePawn();
        addObject(whitePawn7,150,650);
        whitePawn whitePawn8 = new whitePawn();
        addObject(whitePawn8,50,650);
    }
}
